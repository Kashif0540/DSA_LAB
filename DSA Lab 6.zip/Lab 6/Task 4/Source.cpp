#include"myQueue.h"

int main() {
	myQueue<int> obj(10);
	int choice = 0;

	do {
		system("cls");
		cout << "\n Welcome to Customer support Ticket system.";
		cout << "\n1. Enter new ticket(4 digits).";
		cout << "\n2. Remove ticket.";
		cout << "\n3. Check ticket to be resolved.";
		cout << "\n4. Display Ticket Queue ";
		cout << "\n5. Exit: ";
		cout << "\nEnter your choice: ";
		cin >> choice;
		while (choice > 5 || choice < 1) {
			cout << "wrong choice entered. Enter Again: ";
			cin >> choice;
		}
		if (choice == 1) {
			int value;
			cout << "Enter the value: ";
			cin >> value;
			while (value <= 999 || value > 9990) {
				cout << "/ Ticket ID cannot be smaller than 4 digits.\nEnter 4 digit ticket ID:";
				cin >> value;
			}
			obj.enqueue(value);
			
		}
		else if (choice == 2) {
			cout << "Value removed from the Queue: " << obj.dequeue() << endl;
			system("pause");
		}
		else if (choice == 3) {
			cout << "value at the start of the Queue is: " << obj.peek() << endl;
			system("pause");
		}
		else if (choice == 4) {
			cout << "Display: ";
			obj.display();
			system("pause");
		}
	} while (choice != 5);
	cout << "Thanks for using the program." << endl;
	return 0;
}