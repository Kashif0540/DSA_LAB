#include"myQueue.h"

int main() {
	myQueue<int> obj(10);
	int choice = 0;

	do {
		system("cls");
		cout << "\n1. Enter value in Queue(EnQueue): ";
		cout << "\n2. Remove value from Queue(DeQueue): ";
		cout << "\n3. Peek value: ";
		cout << "\n4. Display: ";
		cout << "\n5. Exit: ";
		cout << "\nEnter your choice: ";
		cin >> choice;
		while (choice > 5 || choice < 1) {
			cout << "wrong choice entered. Enter Again: ";
			cin >> choice;
		}
		if (choice == 1) {
			int value;
			cout << "Enter the value: ";
			cin >> value;
			obj.enqueue(value);
			
		}
		else if (choice == 2) {
			cout << "Value removed from the Queue: " << obj.dequeue() << endl;
			system("pause");
		}
		else if (choice == 3) {
			cout << "value at the start of the Queue is: " << obj.peek() << endl;
			system("pause");
		}
		else if (choice == 4) {
			cout << "Display: ";
			obj.display();
			system("pause");
		}
	} while (choice != 5);
	cout << "Thanks for using the program." << endl;
	return 0;
}