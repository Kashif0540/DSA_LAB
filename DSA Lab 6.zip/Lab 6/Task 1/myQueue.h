#include "Queue.h"

template <class T>
class myQueue :public Queue<T>
{
public:
	myQueue(int);
	void enqueue(T value);
	T dequeue();
	T peek();
	void display();
	bool isEmpty();
	bool isFull();
};

template <class T>
bool myQueue<T>::isFull()		
{
	return Queue<T>::maxSize == Queue<T>::currentSize;
}

template <class T>
bool myQueue<T>::isEmpty()		
{
	return Queue<T>::currentSize == 0;
}

template <class T>
void myQueue<T>::display()				
{

	for (int i = 0; i < Queue<T>::currentSize; i++)
		cout << " " << Queue<T>::arr[i];
	cout << endl;
}

template <class T>
myQueue<T>::myQueue(int s) :Queue<T>(s)
{

}

template <class T>				
void myQueue<T>::enqueue(T value)
{
	if (isFull())
	{
		cout << "Queue is FULL" << endl;
	}

	else
	{
		Queue<T>::arr[Queue<T>::currentSize] = value;
		Queue<T>::currentSize++;
	}

}

template <class T>			
T myQueue<T>::dequeue()
{
	if (isEmpty())
	{
		cout << "Queue is Empty" << endl;
		return NULL;
	}

	else
	{
		T returningValue = Queue<T>::arr[0];
		Queue<T>::currentSize--;
		for (int i = 0; i < Queue<T>::currentSize; i++)
		{
			Queue<T>::arr[i] = Queue<T>::arr[i + 1];
		}

		return returningValue;
	}

}


template <class T>			
T myQueue<T>::peek()
{
	if (isEmpty())
	{
		cout << "Queue is Empty" << endl;
		return NULL;
	}

	else
	{
		return Queue<T>::arr[0];
	}

}