#pragma once
#include<iostream>
using namespace std;

template<class T>
class Queue {
protected:
	T* arr;
	int currentSize;
	int maxSize;
public:
	Queue(int size);
	virtual void enQueue(T value) = 0;
	virtual T deQueue() = 0;
	virtual T front() const = 0;
	virtual bool isEmpty() const = 0;
	virtual bool isFull() const = 0;
	virtual ~Queue();
};

template<class T>
Queue<T>::Queue(int size) {
	maxSize = size;
	currentSize = 0;
	arr = new T[maxSize];
}

template<class T>
Queue<T>::~Queue() {
	delete arr;
}
