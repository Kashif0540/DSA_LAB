#include "myQueue.h"

int main() {
    int size = 0;
    cout << "Enter the size of the Queue: ";
    cin >>size;

    myQueue<int> obj(size);
    
    int value;
    cout << "Enter Values in the Queue: ";
    for (int i = 0;i < size;i++) {
        cin >> value;
        obj.enQueue(value);
    }

    int k;

   
        cout << "Enter the Number of Elements you want to Reverse: ";
        cin >> k;
        while (k > size) {
            cout << "Wrong Input Try Again: ";
            cin >> k;
        }

   
    cout << "Origginal Queue: " << endl;
    obj.display();

    if (k <= 1) {
        cout << "No Reversal Needed" << endl;
        cout << "Original Queue is: " << endl;
        obj.display();
    }
    else {
        int* temp = new int[k];
        int s = 0;

        for (int i = 0;i < k;i++) {
            temp[s++] = obj.deQueue();
        }

        for (int i = s - 1;i >= 0;i--) {
            obj.enQueue(temp[i]);
        }
   
        for (int i = 0;i < size - k;i++) {
            obj.enQueue(obj.deQueue());
        }

        cout << "Reversed Queue is: " << endl;
        obj.display();


    }
        
    




    return 0;
}
