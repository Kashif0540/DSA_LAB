//#include"myQueue.h"
//
//int main() {
//	myQueue<string> obj(10);
//	int choice = 0;
//
//	do {
//		system("cls");
//		cout << "\n Welcome to Customer support Ticket system.";
//		cout << "\n1. Add new Print Jobs to the Queue.";
//		cout << "\n2. Remove Document from the Queue.";
//		cout << "\n3. Check Document from Front without Removing.";
//		cout << "\n4. Display Print Jobs. ";
//		cout << "\n5. Exit: ";
//		cout << "\nEnter your choice: ";
//		cin >> choice;
//		while (choice > 5 || choice < 1) {
//			cout << "wrong choice entered. Enter Again: ";
//			cin >> choice;
//		}
//		if (choice == 1) {
//			string doc;;
//			cout << "Enter Document Name: ";
//			cin >> doc;
//			obj.enQueue(doc);
//
//		}
//		else if (choice == 2) {
//			cout << "Document removed from the Queue: " << obj.deQueue() << endl;
//			system("pause");
//		}
//		else if (choice == 3) {
//			cout << "Document at the start of the Queue is : " << obj.front() << endl;
//			system("pause");
//		}
//		else if (choice == 4) {
//			cout << "Display: " << endl;
//			obj.display();
//			system("pause");
//		}
//	} while (choice != 5);
//	cout << "Thanks for using the program." << endl;
//	return 0;
//}